package com.example.ex_tinguisher;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String[] roasts = {
            "Your ex is like a cloud. When they disappear, it’s a beautiful day.",
            "Your ex was the reason shampoo had instructions.",
            "You glowed up so hard, NASA wants to study your orbit.",
            "Your ex? More red flags than a communist parade.",
            "If they text you again, send them a Paytm bill for wasting your time.",
            "Healing looks good on you. Your ex doesn’t.",
            "Your ex is the reason horoscopes come with warnings.",
            "They weren’t emotionally unavailable. They were emotionally bankrupt.",
            "You dated them? That was your charity work for the decade.",
            "If your ex was a browser tab, they’d constantly crash.",
            "Their toxic trait? Breathing near good people.",
            "Your ex peaked in the group chat and that’s sad.",
            "They’re proof not everyone deserves a phone or feelings.",
            "You didn’t lose them. You dodged a therapy bill.",
            "Your ex is the human version of a low battery warning.",
            "They thought they were mysterious, but they were just confusing and unemployed.",
            "You were the Wi-Fi. They were the glitchy router.",
            "They gave 0 effort and still expected 5-star treatment.",
            "The only thing consistent about them was their inconsistencies.",
            "Dating them was like subscribing to ads—unskippable pain.",
            "If red flags were a person, it’d be them in a group photo.",
            "They ghosted you? Great! Now haunt their nightmares with your glow-up.",
            "Your glow-up is so dangerous, even their next won’t recover.",
            "Their biggest flex is surviving without your grace.",
            "Your ex’s best quality was your patience.",
            "You’re not heartbroken. You’re emotionally detoxed."
    };

    TextView roastOutput, timerText;
    Button btnRoast, btnDontText, btnPetty, btnPowerful, btnPeaceful;

    CountDownTimer countdown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        roastOutput = findViewById(R.id.roastOutput);
        timerText = findViewById(R.id.timerText);
        btnRoast = findViewById(R.id.btnRoast);
        btnDontText = findViewById(R.id.btnDontText);
        btnPetty = findViewById(R.id.btnPetty);
        btnPowerful = findViewById(R.id.btnPowerful);
        btnPeaceful = findViewById(R.id.btnPeaceful);

        btnRoast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random r = new Random();
                int index = r.nextInt(roasts.length);
                roastOutput.setText(roasts[index]);
            }
        });

        btnPetty.setOnClickListener(v -> Toast.makeText(this, "Being petty is a power move 😌", Toast.LENGTH_SHORT).show());

        btnPowerful.setOnClickListener(v -> Toast.makeText(this, "Yes! You're thriving 🔥", Toast.LENGTH_SHORT).show());

        btnPeaceful.setOnClickListener(v -> Toast.makeText(this, "Inner peace unlocked ✨", Toast.LENGTH_SHORT).show());

        btnDontText.setOnClickListener(v -> {
            if (countdown != null) countdown.cancel();

            countdown = new CountDownTimer(30000, 1000) {
                public void onTick(long millisUntilFinished) {
                    timerText.setText("Hold up... " + millisUntilFinished / 1000 + "s left");
                }

                public void onFinish() {
                    timerText.setText("Crisis averted. You did not text your ex 👏");
                }
            }.start();
        });
    }
}
